import Liked from './Liked';

export default Liked;
