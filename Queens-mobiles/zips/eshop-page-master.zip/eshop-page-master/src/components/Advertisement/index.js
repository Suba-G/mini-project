import Advertisement from './Advertisement';

export default Advertisement;
