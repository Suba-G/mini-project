import "./style.scss";

export { Login } from "./login";
export { Register } from "./register";
